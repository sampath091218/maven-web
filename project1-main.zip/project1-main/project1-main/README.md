integrating with jenkins

it is added
